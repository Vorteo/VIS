﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MobilObchod.ORM
{
    public class PolozkaObjednavky
    {
        public int oId { get; set; }
        public int pId { get; set; }
        public int Mnozstvi { get; set; }

        public string NazevProduktu { get; set; }

    }
}
