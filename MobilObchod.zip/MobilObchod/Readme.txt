Návod:

1. Pro spuštění aplikace je potřeba být ve školní sítí, případně použít VPN do školní sítě ( https://idoc.vsb.cz/xwiki/bin/view/tuonet/vpn/ ).
2. Při spouštění projektu je třeba nastavit, který projekt se má spouštět -> vybrat WindowsFormApp (ve Visual Studiu stačí jen v comboboxu zvolit daný projekt).
3. Po zapnutí aplikace naběhne přihlašovací obrazovka, kde stačí do pole "Ověřovací kod" napsat "Admin" a dostanete se do hlavní nabídky jako Administrátor.
4. Dále už je možné s aplikací pracovat podle GUI.
5. Exportovane XML soubor se uklada do slozky bin/debug/netcoreapp3.1

Poznámka:
Jinak tam mám udělané přihlašování přes login, který uživatel používá v systému aplikace, 
kdy zadám login a heslo k mail k svému mail serveru, který pošle ověřovací kod na mailovou adresu, kterým se následně přihlásím.
