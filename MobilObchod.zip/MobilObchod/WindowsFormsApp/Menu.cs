﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Hide();
            Form1 createForm = new Form1();
            createForm.Show();           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Hide();
            OverviewProducts overview = new OverviewProducts();
            overview.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Hide();
            Stats stats = new Stats();
            stats.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Hide();
            UsersOverview usersO = new UsersOverview();
            usersO.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Hide();
            LogIncs logIncs = new LogIncs();
            logIncs.Show();
        }

        private void Menu_Load(object sender, EventArgs e)
        {
            int i = 0;
            foreach(var x in LogIncs.user)
            {
                i++;
            }
            if (i <= 0)
            {
                label2.Text = "Admin";
            }
            else
            {
                label2.Text = LogIncs.user[0].Jmeno + " " + LogIncs.user[0].Prijmeni + " (" + LogIncs.user[0].Typ_uzivatele + ") ";
            }
        }
    }
}
