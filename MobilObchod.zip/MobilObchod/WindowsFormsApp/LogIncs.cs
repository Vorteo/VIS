﻿using MobilObchod.ORM;
using MobilObchod.ORM.dao;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Net.Mail;
using System.Linq;


namespace WindowsFormsApp
{
    public partial class LogIncs : Form
    {
        public static Collection<Uzivatel> user = new Collection<Uzivatel>();
        string password = "Admin";
        public LogIncs()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Collection<Uzivatel> uzivatels = UzivatelTable.Select();
            foreach (Uzivatel u in uzivatels)
            {
                if(u.Login == loginbox.Text)
                {
                    user.Add(u);
                    try
                    {
                        MailMessage mail = new MailMessage();
                        SmtpClient SmtServer = new SmtpClient("smtp.gmail.com");

                        mail.From = new MailAddress("martin.kolotocc@gmail.com");
                        mail.To.Add("martin.kolotocc@gmail.com"); // address   u.Email
                        mail.Subject = "Ověřovací kod";

                        const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
                        Random random = new Random();
                        password = new string(Enumerable.Repeat(chars, 8).Select(s => s[random.Next(s.Length)]).ToArray());


                        mail.Body = "Váš ověřovací kod je: " + password;

                        SmtServer.Port = 587;
                        SmtServer.Credentials = new System.Net.NetworkCredential("martin.kolotocc@gmail.com", passwd.Text);
                        SmtServer.EnableSsl = true;

                        SmtServer.Send(mail);

          
                        MessageBox.Show("Ověřovací mail odeslán.");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if((password == textBox1.Text))
            {
                MessageBox.Show("Uživatel úspěšně přihlášen");
                Hide();
                Menu menu = new Menu();
                menu.Show();
            }
            else
            {
                MessageBox.Show("Špatný ověřovací kod");
            }
        }
    }
}
