﻿using MobilObchod.ORM;
using MobilObchod.ORM.dao;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Linq;

namespace WindowsFormsApp
{
    public partial class CreateUser : Form
    {
        public static Collection<Uzivatel> collection = UzivatelTable.Select();
        public CreateUser()
        {
            InitializeComponent();
   
            List<string> values = new List<string>();
            /*
            foreach (Uzivatel u in collection)
            {
                values.Add(u.Typ_uzivatele);
            }
            var q = (from d in values select d).Distinct();
            */
            values.Add("Registrovany zakaznik");
            values.Add("Neregistrovany zakaznik");
            values.Add("Pracovnik");
            values.Add("Spravce");

            foreach (var p in values)
            {
                comboBox1.Items.Add(p);
            }
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;


        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (fname.Text != "" && lname.Text != "" && phone.Text != "" && email.Text != "" && street.Text != "" && city.Text != "" && psc.Text != "" && country.Text != "")
            {
                bool success = false;
                int _psc;
                success = Int32.TryParse(psc.Text, out _psc);
                if (success == false)
                {
                    MessageBox.Show("Spatne napsane PSC!");
                    return;
                }

                Adresa adresa = new Adresa()
                {
                    Mesto = city.Text,
                    Ulice = street.Text,
                    Psc = psc.Text,
                    Zeme = country.Text,
                    Datum_zmeny = DateTime.Now
                };
                AdresaTable.Insert(adresa);

                if (comboBox1.SelectedIndex >= 0)
                {
                    var p = comboBox1.SelectedItem.ToString();
                    if(p == "Registrovany zakaznik" || p == "Pracovnik" || p == "Spravce" )
                    {
                        string login = lname.Text.Substring(0,4).ToUpper();
                        byte[] tempBytes;
                        tempBytes = System.Text.Encoding.GetEncoding("ISO-8859-8").GetBytes(login);
                        string login1 = System.Text.Encoding.UTF8.GetString(tempBytes);
                        string login2 = login1; // temp

                        Random random = new Random();
                        login1 = login1 + "" + random.Next(1000,9000).ToString();

                        foreach(Uzivatel u in collection)
                        {
                            if(u.Login == login1)
                            {
                                login1 = login2 + "" + random.Next(1000, 9000).ToString();
                            }
                        }

                        Uzivatel uzivatel = new Uzivatel()
                        {
                            Jmeno = fname.Text,
                            Prijmeni = lname.Text,
                            Telefon = phone.Text,
                            Email = email.Text,
                            IdAdresa = adresa.Id,
                            Is_active = true,
                            Typ_uzivatele = comboBox1.SelectedItem.ToString(),
                            Adresa = adresa,
                            Datum_zmeny = DateTime.Now,
                            Login = login1,
                            Datum_registrace = DateTime.Now,

                        };
                        UzivatelTable.Insert(uzivatel);
                        this.Hide();
                    }
                    else
                    {
                        Uzivatel uzivatel = new Uzivatel()
                        {
                            Jmeno = fname.Text,
                            Prijmeni = lname.Text,
                            Telefon = phone.Text,
                            Email = email.Text,
                            IdAdresa = adresa.Id,
                            Is_active = true,
                            Typ_uzivatele = comboBox1.SelectedItem.ToString(),
                            Adresa = adresa,
                            Datum_zmeny = DateTime.Now,
                        };
                        UzivatelTable.Insert(uzivatel);
                    }
                }
            }
            else
            {
                MessageBox.Show("Musíš vyplnit všechny položky!");
            }

        }
    }
}
