﻿using System;
using MobilObchod.ORM;
using MobilObchod.ORM.dao;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections.ObjectModel;

namespace WindowsFormsApp
{
    public partial class Stats : Form
    {
        BindingList<ObjednavkaStatistika> bindingList = new BindingList<ObjednavkaStatistika>();
        int year;
        public Stats()
        {
            InitializeComponent();
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Měsíc",

            });
            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Celková cena",

            });
            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Počet objednávek",

            });
            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Počet uživatelů",

            });
            Refresh();

        }
        private void Refresh(int year = 2020)
        {
            Collection<Objednavka> objs = ObjednavkaTable.Select();
            bindingList.Clear();

            int sum = 0;
            int countobj = 0, countuser = 0;
            Collection<ObjednavkaStatistika> stat = new Collection<ObjednavkaStatistika>();

            for (int i = 1; i <= 12; i++)
            {
                foreach (var o in objs)
                {
                    if (o.Datum_vytvoreni.Year == year)
                    {
                        if (o.Datum_vytvoreni.Month == i)
                        {
                            sum += (int)o.Celkova_cena;
                            countobj++;
                            countuser++;
                        }
                    }                   
                }
                ObjednavkaStatistika objst = new ObjednavkaStatistika() { Period = i, Sum = sum, CountObj = countobj, CountUzivatel = countuser };
                stat.Add(objst);
                sum = 0;
                countobj = 0;
                countuser = 0;
            }

            bindingList = new BindingList<ObjednavkaStatistika>(stat);
            dataGridView1.Rows.Clear();
            foreach (var o in stat)
            {
                dataGridView1.Rows.Add(o.Period, o.Sum, o.CountObj, o.CountUzivatel);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Hide();
            Menu menu = new Menu();
            menu.Show();
        }
        // Zobrazeni
        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                year = 0;
            }
            else
            {
                if (!int.TryParse(textBox1.Text, out year))
                {
                    MessageBox.Show("Zadejte číslo!");
                }
            }
            Refresh(year);
        }
    }
}
