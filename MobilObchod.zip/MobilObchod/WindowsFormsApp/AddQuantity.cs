﻿using MobilObchod.ORM;
using MobilObchod.ORM.dao;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp
{
    public partial class AddQuantity : Form
    {
        public AddQuantity()
        {
            InitializeComponent();
            Collection<Produkt> products = ProduktTable.SelectProducts();
            foreach (var p in products)
            {
                comboBox1.Items.Add(p);
            }
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "")
            {
                bool success = false;
                int num;
                success = Int32.TryParse(textBox1.Text, out num);
                if (success == false)
                {
                    // return;
                }
                if (comboBox1.SelectedIndex >= 0)
                {
                    Produkt p1 = comboBox1.SelectedItem as Produkt;
                    p1.Pocet_kusu += num;

                    ProduktTable.Update(p1);
                    MessageBox.Show("Přidáno");
                    Hide();
                }
                }
        }
    }
}
