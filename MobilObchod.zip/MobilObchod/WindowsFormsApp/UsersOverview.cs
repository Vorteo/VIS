﻿using System;
using MobilObchod.ORM;
using MobilObchod.ORM.dao;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections.ObjectModel;

namespace WindowsFormsApp
{
    public partial class UsersOverview : Form
    {
        BindingList<Uzivatel> bindingList = new BindingList<Uzivatel>();
        int druh;
        string keyword;
        public UsersOverview()
        {
            InitializeComponent();
            dataGridView1.AutoGenerateColumns = false;

            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Jméno",
                DataPropertyName = nameof(Uzivatel.Jmeno),

            });

            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Příjmení",
                DataPropertyName = nameof(Uzivatel.Prijmeni),

            });
            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Telefon",
                DataPropertyName = nameof(Uzivatel.Telefon),

            });
            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Email",
                DataPropertyName = nameof(Uzivatel.Email),

            });
            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Druh",
                DataPropertyName = nameof(Uzivatel.Typ_uzivatele),

            });
            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Login",
                DataPropertyName = nameof(Uzivatel.Login),

            });
            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Registrace",
                DataPropertyName = nameof(Uzivatel.Datum_registrace),

            });
            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Aktivní",
                DataPropertyName = nameof(Uzivatel.Is_active),

            });
            dataGridView1.Columns.Add(new DataGridViewButtonColumn()
            {
                UseColumnTextForButtonValue = true,
                Text = "Smazat",
                Name = "Delete"
            });
            Refresh();
        }
        private void Refresh(int druh = 0, string keyword = "")
        {
            Collection<Uzivatel> users = UzivatelTable.Select();
            string type = "";
            switch (druh)
            {
                case 0:
                    type = "Vše";
                    break;
                case 1:
                    type = "Neregistrovany zakaznik";
                    break;
                case 2:
                    type = "Pracovnik";
                    break;
                case 3:
                    type = "Spravce";
                    break;
            }

            Collection<Uzivatel> users1 = new Collection<Uzivatel>();

            foreach (Uzivatel u in users)
            {
                if ((keyword != null))
                {
                    string name = u.Jmeno + " " + u.Prijmeni;
                    if ((type == "Neregistrovany zakaznik") && (name.Equals(keyword)))
                    {
                        if ((u.Typ_uzivatele == "Registrovany zakaznik") || (u.Typ_uzivatele == type))
                        {
                            users1.Add(u);
                        }
                    }
                    else
                    {
                        if ((name.Equals(keyword)) && ((u.Typ_uzivatele == type)))
                        {
                            users1.Add(u);
                        }
                        if ((name.Equals(keyword)) && (type == "Vše"))
                        {
                            users1.Add(u);
                        }
                    }             
                }
                else
                {
                    if (type == "Neregistrovany zakaznik")
                    {
                        if ((u.Typ_uzivatele == "Registrovany zakaznik") || (u.Typ_uzivatele == type))
                        {
                            users1.Add(u);
                        }
                    }
                    else
                    {
                        if ((u.Typ_uzivatele == type))
                        {
                            users1.Add(u);
                        }
                        if (type == "Vše")
                        {
                            users1.Add(u);
                        }
                    }
                }

            }

            bindingList.Clear();
            bindingList = new BindingList<Uzivatel>(users1);
            dataGridView1.DataSource = bindingList;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Hide();
            Menu menu = new Menu();
            menu.Show();
        }
        private void dataGridView1_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            for (int i = 0; i < bindingList.Count; i++)
            {
                if (bindingList[i].Is_active == false)
                {
                    dataGridView1.Rows[i].Cells["Delete"] = new DataGridViewTextBoxCell()
                    {
                        Value = "Nelze smazat"
                    };
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridView datagrid = sender as DataGridView;

            Uzivatel user = bindingList[e.RowIndex];
            if (datagrid.Columns[e.ColumnIndex].Name == "Delete")
            {
                if (datagrid.Rows[e.RowIndex].Cells["Delete"] is DataGridViewButtonCell)
                {
                    UzivatelTable.Delete(user);
                    Refresh();

                }
            }
        }

        private void UsersOverview_Load(object sender, EventArgs e)
        {
            Collection<Uzivatel> users = UzivatelTable.Select();
            bindingList.Clear();
            bindingList = new BindingList<Uzivatel>(users);
            dataGridView1.DataSource = bindingList;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                keyword = null;
            }
            else
            {
                keyword = textBox1.Text;
            }
            if (radioButton6.Checked)
            {
                druh = 0;
            }
            if (radioButton1.Checked)
            {
                druh = 1;
            }
            if (radioButton2.Checked)
            {
                druh = 2;
            }
            if (radioButton3.Checked)
            {
                druh = 3;
            }
            Refresh(druh,keyword);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            CreateUser createUser = new CreateUser();
            createUser.Show();
            Refresh();
        }
    }
}
